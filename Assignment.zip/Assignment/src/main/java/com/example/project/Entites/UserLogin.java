package com.example.project.Entites;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class UserLogin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@OneToOne
	User user;
	
	private String status;
	private String token;
	
	private LocalDateTime created_at;

	public UserLogin(User user, String status, String token, LocalDateTime created_at) {
		super();
		this.user = user;
		this.status = status;
		this.token = token;
		this.created_at = created_at;
	}

}
