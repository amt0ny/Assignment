package com.example.project.model;

public class JwtResquest {
	
	private String name;
	private String password;

	public JwtResquest() {
		super();		// Try removing super
		// TODO Auto-generated constructor stub
	}

	public JwtResquest(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public String toString() {
		return "JwtResquest [name=" + name + ", password=" + password + "]";
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	

}
