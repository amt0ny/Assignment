package com.example.project.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.Entites.User;
import com.example.project.Entites.UserDetails;
import com.example.project.Entites.UserLogin;
import com.example.project.dto.UserDetailDto;
import com.example.project.jwtController.JwtController;
import com.example.project.model.JwtResquest;
import com.example.project.repo.UserDetailsRepo;
import com.example.project.repo.UserLoginRepo;
import com.example.project.repo.UserRepo;

@RestController
public class Controller {
	
	
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private UserLoginRepo userLoginRepo;
	
	@Autowired
	private UserDetailsRepo userDetailsRepo;
	
	
	
	// API's for USER 
	
	@GetMapping("/getAllUsers")
	public List<User> getUsers() {
		
		return userRepo.findAll();
		
	}
	
	
	@PostMapping("/addUser")
	public void addUser(@RequestBody User user) {
		 this.userRepo.save(user);
		 
	}
	
	
	// API's for USER DETAILS
	
	@PostMapping("/addUserDetails")
	public UserDetails addUserDetails(@RequestBody UserDetailDto userDetailsdto) {
		UserDetails userDetails = userDetailsRepo.getUserDetailsByUserId(userDetailsdto.getId());
		User user = userRepo.getUserById(userDetailsdto.getId());
		UserDetails userDetail = new UserDetails(user, userDetailsdto.getName(), userDetailsdto.getNumber(), userDetailsdto.getEmail(), userDetailsdto.getLinkedin(), LocalDateTime.now(), LocalDateTime.now());
		UserDetails userDetails2 = this.userDetailsRepo.save(userDetail);
		return userDetails2;
	}


	
	
	
	
	
	
	


}
