package com.example.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.project.Entites.*;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepo extends JpaRepository<User, Integer>{

	static org.springframework.security.core.userdetails.User getUsername() {
		
		return getUsername();
		
	}
	
	@Query("select u from User u where u.username = :username")
	public User getUserByUsername(@Param("username") String username);

	User save(User user);
	
	@Query("select u from User u where u.id = :id")
	public User getUserById(@Param("id") Integer id);
	
//	
	

}
