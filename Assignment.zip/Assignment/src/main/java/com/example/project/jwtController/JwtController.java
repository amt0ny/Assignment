package com.example.project.jwtController;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.Entites.User;
import com.example.project.Entites.UserLogin;
import com.example.project.helper.JwtUtil;
import com.example.project.jwtresponse.JwtResponse;
import com.example.project.model.JwtResquest;
import com.example.project.repo.UserLoginRepo;
import com.example.project.repo.UserRepo;
import com.example.project.security.CustomUserDetailService;



@RestController
public class JwtController {
	
	static String token;
	
	@Autowired
	private CustomUserDetailService customUserDetailService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private UserLoginRepo userLoginRepo;
	
	@PostMapping("/token")
	public ResponseEntity<?> generateToken(@RequestBody User user) throws Exception{
		System.out.println(user);
		
		
		
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
			
		} catch (UsernameNotFoundException e) {
			e.printStackTrace();
			
			throw new Exception("Bad Credential");
		} catch (BadCredentialsException e) {
			e.printStackTrace();
			
			throw new Exception("Wrong Username or Password");
		}
		
		token = this.jwtUtil.generateToken(user.getUsername());
		System.out.println("Jwt token : "+token);
		
		UserLogin usertoken = new UserLogin(user, "Success", token, LocalDateTime.now());
		
		userLoginRepo.save(usertoken);
		
		return ResponseEntity.ok(new JwtResponse(token));
		
	}
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	

}
