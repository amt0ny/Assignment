package com.example.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.project.Entites.*;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDetailsRepo extends JpaRepository<UserDetails, Integer>{
	
	
	@Query("select u from UserDetails u join u.user a where a.id = :id")
	public UserDetails getUserDetailsByUserId(@Param("id") Integer id);

}
