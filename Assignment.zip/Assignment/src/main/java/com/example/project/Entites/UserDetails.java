package com.example.project.Entites;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class UserDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@OneToOne
	User user;
	
	private String name;
	private String number;
	private String email;
	private String linkedin;
	private LocalDateTime created_at;
	private LocalDateTime updated_at;
	public UserDetails(User user, String name, String number, String email, String linkedin, LocalDateTime created_at,
			LocalDateTime updated_at) {
		super();
		this.user = user;
		this.name = name;
		this.number = number;
		this.email = email;
		this.linkedin = linkedin;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}
	
	
	

}
